package org.alnoor.zakat

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ZakatCalculatorTest {
    @Test fun calculatesTwoPointFivePercentWhenAboveNisab() {
        val result = ZakatCalculator.calculate(1_000_000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 500_000.0)
        assertTrue(result.eligible)
        assertEquals(25_000.0, result.zakatDue, 0.01)
    }
    @Test fun noZakatBelowNisab() {
        val result = ZakatCalculator.calculate(100_000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 500_000.0)
        assertFalse(result.eligible)
        assertEquals(0.0, result.zakatDue, 0.01)
    }
    @Test fun debtsReduceEligibleAssets() {
        val result = ZakatCalculator.calculate(1_000_000.0, 0.0, 0.0, 0.0, 0.0, 0.0, 200_000.0, 500_000.0)
        assertEquals(800_000.0, result.netAssets, 0.01)
        assertEquals(20_000.0, result.zakatDue, 0.01)
    }
}
