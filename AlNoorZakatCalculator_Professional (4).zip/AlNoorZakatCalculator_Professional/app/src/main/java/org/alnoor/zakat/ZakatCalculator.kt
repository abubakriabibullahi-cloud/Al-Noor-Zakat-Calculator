package org.alnoor.zakat

data class ZakatBreakdown(
    val totalAssets: Double,
    val deductions: Double,
    val netAssets: Double,
    val nisab: Double,
    val zakatDue: Double,
    val eligible: Boolean
)

object ZakatCalculator {
    fun calculate(
        cash: Double,
        goldValue: Double,
        silverValue: Double,
        business: Double,
        investments: Double,
        otherEligible: Double,
        deductibleDebts: Double,
        nisabValue: Double,
        rate: Double = 0.025
    ): ZakatBreakdown {
        val values = listOf(cash, goldValue, silverValue, business, investments, otherEligible,
            deductibleDebts, nisabValue, rate)
        require(values.all { it.isFinite() && it >= 0.0 }) { "Values must be finite and non-negative." }
        require(rate <= 1.0) { "Rate must not exceed 100%." }
        val assets = cash + goldValue + silverValue + business + investments + otherEligible
        val deductions = deductibleDebts.coerceAtMost(assets)
        val net = (assets - deductions).coerceAtLeast(0.0)
        val eligible = nisabValue > 0.0 && net >= nisabValue
        return ZakatBreakdown(assets, deductions, net, nisabValue, if (eligible) net * rate else 0.0, eligible)
    }
}
