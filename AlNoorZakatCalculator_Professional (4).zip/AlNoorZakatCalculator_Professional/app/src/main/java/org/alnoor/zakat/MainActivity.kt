package org.alnoor.zakat

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

private val Forest = Color(0xFF0E5A43)
private val ForestDark = Color(0xFF073D2E)
private val Gold = Color(0xFFC5A24A)
private val Cream = Color(0xFFF7F5EF)
private val Ink = Color(0xFF1D2924)
private val Muted = Color(0xFF68766F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlNoorApp(applicationContext) }
    }
}

private data class AppPage(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val detail: String)

private val pages = listOf(
    AppPage("Welcome", Icons.Default.WavingHand, "A thoughtful guide to calculating your Zakat."),
    AppPage("Home", Icons.Default.Home, "Your Zakat journey at a glance."),
    AppPage("Zakat Calculator", Icons.Default.Calculate, "Estimate eligible assets and your Zakat due."),
    AppPage("Cash & Savings", Icons.Default.AccountBalanceWallet, "Cash on hand, bank balances and savings."),
    AppPage("Gold", Icons.Default.Diamond, "Enter the value of Zakat-eligible gold."),
    AppPage("Silver", Icons.Default.Circle, "Enter the value of Zakat-eligible silver."),
    AppPage("Business Assets", Icons.Default.Store, "Eligible trade inventory and business receivables."),
    AppPage("Investments", Icons.Default.TrendingUp, "Review investments under your chosen scholarly method."),
    AppPage("Debt Deductions", Icons.Default.ReceiptLong, "Record debts that may be deductible."),
    AppPage("Nisab & Prices", Icons.Default.Monitoring, "Choose a Nisab basis and enter current local prices."),
    AppPage("Calculation Results", Icons.Default.Assessment, "Review the calculation breakdown."),
    AppPage("History", Icons.Default.History, "Saved calculations are kept on this device."),
    AppPage("Reports", Icons.Default.Description, "Review and share a plain-text calculation summary."),
    AppPage("Hawl & Reminders", Icons.Default.NotificationsActive, "Plan your Zakat date and annual review."),
    AppPage("Islamic Learning", Icons.Default.MenuBook, "Learn key concepts and terms."),
    AppPage("Zakat Guide", Icons.Default.AutoStories, "General guidance and areas where opinions differ."),
    AppPage("Settings", Icons.Default.Settings, "Set language, currency, Nisab preference and privacy."),
    AppPage("Privacy", Icons.Default.Security, "Your calculations stay on this device."),
    AppPage("About Al-Noor", Icons.Default.Info, "Light of Mercy — a practical Zakat companion."),
    AppPage("Help & Disclaimer", Icons.Default.HelpOutline, "Important notes before relying on an estimate.")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlNoorApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("alnoor_local", Context.MODE_PRIVATE) }
    var selectedPage by remember { mutableStateOf("Home") }
    var language by remember { mutableStateOf(prefs.getString("language", "English") ?: "English") }
    var nisabBasis by remember { mutableStateOf(prefs.getString("nisab_basis", "Silver") ?: "Silver") }
    var cash by remember { mutableStateOf(prefs.getString("cash", "") ?: "") }
    var gold by remember { mutableStateOf(prefs.getString("gold", "") ?: "") }
    var silver by remember { mutableStateOf(prefs.getString("silver", "") ?: "") }
    var business by remember { mutableStateOf(prefs.getString("business", "") ?: "") }
    var investments by remember { mutableStateOf(prefs.getString("investments", "") ?: "") }
    var otherAssets by remember { mutableStateOf(prefs.getString("other", "") ?: "") }
    var debts by remember { mutableStateOf(prefs.getString("debts", "") ?: "") }
    var goldNisab by remember { mutableStateOf(prefs.getString("gold_nisab", "2500000") ?: "2500000") }
    var silverNisab by remember { mutableStateOf(prefs.getString("silver_nisab", "150000") ?: "150000") }
    var result by remember { mutableStateOf<ZakatBreakdown?>(null) }
    var history by remember { mutableStateOf(loadHistory(prefs)) }
    var status by remember { mutableStateOf("") }
    val formatter = remember { NumberFormat.getCurrencyInstance(Locale("en", "NG")) }

    fun num(s: String) = s.trim().replace(",", "").toDoubleOrNull() ?: 0.0
    fun calculate() {
        try {
            result = ZakatCalculator.calculate(
                num(cash), num(gold), num(silver), num(business), num(investments), num(otherAssets),
                num(debts), if (nisabBasis == "Gold") num(goldNisab) else num(silverNisab)
            )
            selectedPage = "Calculation Results"
            status = ""
        } catch (e: IllegalArgumentException) {
            status = e.message ?: "Please check your entries."
        }
    }
    fun save() {
        prefs.edit()
            .putString("cash", cash).putString("gold", gold).putString("silver", silver)
            .putString("business", business).putString("investments", investments)
            .putString("other", otherAssets).putString("debts", debts)
            .putString("gold_nisab", goldNisab).putString("silver_nisab", silverNisab)
            .putString("nisab_basis", nisabBasis).putString("language", language).apply()
        status = "Saved on this device."
    }
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Forest, onPrimary = Color.White, secondary = Gold,
            background = Cream, surface = Color.White, onSurface = Ink)
    ) {
        Scaffold(
            containerColor = Cream,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Al-Noor", fontWeight = FontWeight.Bold, color = ForestDark)
                            Text("ZAKAT CALCULATOR", fontSize = 10.sp, letterSpacing = 2.sp, color = Muted)
                        }
                    },
                    navigationIcon = {
                        Box(Modifier.padding(start = 12.dp).size(38.dp).background(Forest, RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Favorite, contentDescription = "Al-Noor emblem", tint = Gold)
                        }
                    },
                    actions = {
                        IconButton(onClick = { selectedPage = "Settings" }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Forest)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Cream)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Zakat Calculator", "History", "Settings").forEach { name ->
                        val p = pages.first { it.title == name }
                        NavigationBarItem(
                            selected = selectedPage == name,
                            onClick = { selectedPage = name },
                            icon = { Icon(p.icon, contentDescription = name) },
                            label = { Text(if (name == "Zakat Calculator") "Calculate" else name, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp)) {
                when (selectedPage) {
                    "Welcome" -> WelcomeScreen { selectedPage = "Home" }
                    "Home" -> HomeScreen(
                        onCalculate = { selectedPage = "Zakat Calculator" },
                        onNavigate = { selectedPage = it },
                        result = result,
                        formatter = formatter
                    )
                    "Zakat Calculator" -> CalculatorScreen(
                        cash, { cash = it }, gold, { gold = it }, silver, { silver = it },
                        business, { business = it }, investments, { investments = it },
                        otherAssets, { otherAssets = it }, debts, { debts = it },
                        nisabBasis, { nisabBasis = it }, goldNisab, { goldNisab = it },
                        silverNisab, { silverNisab = it }, formatter, status,
                        onSave = { save() }, onCalculate = { calculate() }
                    )
                    "Cash & Savings" -> AssetDetailScreen("Cash & Savings", "Include cash, bank balances and eligible savings. Avoid double-counting amounts listed elsewhere.", cash, { cash = it }, onSave = { save() })
                    "Gold" -> AssetDetailScreen("Gold", "Enter the estimated eligible value of gold. Personal-use jewellery treatment differs between scholarly opinions; consult a trusted scholar.", gold, { gold = it }, onSave = { save() })
                    "Silver" -> AssetDetailScreen("Silver", "Enter the estimated eligible value of silver. Use a current, locally relevant valuation.", silver, { silver = it }, onSave = { save() })
                    "Business Assets" -> AssetDetailScreen("Business Assets", "Enter eligible trade inventory and receivables according to the method you follow. Fixed equipment is generally treated differently from stock for sale.", business, { business = it }, onSave = { save() })
                    "Investments" -> AssetDetailScreen("Investments", "Investment treatment depends on asset type, intention and scholarly method. Enter only the amount you have determined is eligible.", investments, { investments = it }, onSave = { save() })
                    "Debt Deductions" -> AssetDetailScreen("Debt Deductions", "Enter only debts you have determined may be deducted under the scholarly approach you follow. Do not automatically deduct every long-term liability.", debts, { debts = it }, onSave = { save() })
                    "Nisab & Prices" -> NisabScreen(nisabBasis, { nisabBasis = it }, goldNisab, { goldNisab = it }, silverNisab, { silverNisab = it }, onSave = { save() })
                    "Calculation Results" -> ResultsScreen(result, formatter, onSave = {
                        result?.let { r ->
                            history = saveHistory(prefs, r)
                            status = "Calculation saved to local history."
                        }
                    }, onHistory = { selectedPage = "History" }, status = status)
                    "History" -> HistoryScreen(history, formatter, onClear = {
                        prefs.edit().remove("history").apply()
                        history = emptyList()
                    })
                    "Reports" -> ReportScreen(result, formatter, onShare = { status = "For sharing, use your device's share menu after copying the summary from Results." }, status = status)
                    "Hawl & Reminders" -> InfoScreen("Hawl & Reminders", "Many forms of Zakat involve a lunar-year (hawl) condition, but details vary by asset and scholarly opinion. This screen is a planning aid only; scheduled notifications are not enabled in this version.", listOf("Record the date you first reached Nisab", "Review eligible assets around your annual Zakat date", "Use a Hijri calendar or qualified local guidance"))
                    "Islamic Learning" -> InfoScreen("Islamic Learning", "A short glossary for learning. Please consult reliable Islamic scholarship for detailed rulings.", listOf("Zakat — obligatory almsgiving under defined conditions", "Nisab — minimum qualifying threshold", "Hawl — lunar year condition for many asset categories", "Eligible assets — assets included under the method you follow"))
                    "Zakat Guide" -> InfoScreen("Zakat Guide", "Zakat rulings can differ across madhhabs and scholars. This app uses a simplified estimate and does not issue a fatwa.", listOf("Confirm the treatment of personal jewellery", "Check business inventory and receivables rules", "Review short-term versus long-term debt treatment", "Confirm investment-specific rules with a qualified scholar"))
                    "Settings" -> SettingsScreen(language, { language = it; prefs.edit().putString("language", it).apply() }, nisabBasis, { nisabBasis = it; prefs.edit().putString("nisab_basis", it).apply() }, onNavigate = { selectedPage = it })
                    "Privacy" -> InfoScreen("Privacy", "This initial version stores entries and calculation history locally using Android SharedPreferences. It does not include cloud sync or an account. Clearing app data or uninstalling may remove saved records.", listOf("No sign-in required", "No cloud history in this version", "Do not share screenshots containing sensitive financial details"))
                    "About Al-Noor" -> InfoScreen("About Al-Noor", "Al-Noor Zakat Calculator — Light of Mercy. A practical companion for organizing eligible assets and estimating Zakat in Nigerian Naira.", listOf("Designed for clarity and privacy", "English interface with Arabic language foundation", "Review all estimates before making a payment"))
                    "Help & Disclaimer" -> InfoScreen("Help & Disclaimer", "This app is an estimation tool, not financial, legal or religious advice. It may not cover every asset category or scholarly position. Market values entered manually can become outdated.", listOf("Verify prices independently", "Check the calculation method with a qualified scholar", "The app does not transfer or pay Zakat", "Do not rely on an estimate without reviewing your circumstances"))
                    else -> InfoScreen(selectedPage, pages.find { it.title == selectedPage }?.detail ?: "Al-Noor tools", listOf("Use the calculator to estimate your Zakat", "Save entries to this device", "Review the disclaimer before relying on a result"))
                }
                Spacer(Modifier.height(20.dp))
                Text("AL-NOOR • LIGHT OF MERCY", modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun WelcomeScreen(onContinue: () -> Unit) {
    Spacer(Modifier.height(26.dp))
    Box(Modifier.fillMaxWidth().background(Forest, RoundedCornerShape(28.dp)).padding(28.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Favorite, null, tint = Gold, modifier = Modifier.size(58.dp))
            Spacer(Modifier.height(16.dp))
            Text("Light of Mercy", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("Your Zakat, thoughtfully calculated", color = Color.White.copy(alpha = .85f))
            Spacer(Modifier.height(22.dp))
            Button(onClick = onContinue, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = ForestDark)) {
                Text("Get started", fontWeight = FontWeight.Bold)
            }
        }
    }
    Spacer(Modifier.height(20.dp))
    InfoCard("Private by design", "Your figures are stored locally on this device in this version.")
    InfoCard("Clear calculations", "Review assets, deductions, Nisab and the final estimate in one place.")
    InfoCard("Scholarly care", "Different situations can have different rulings. This app is an estimate, not a fatwa.")
}

@Composable
private fun HomeScreen(onCalculate: () -> Unit, onNavigate: (String) -> Unit, result: ZakatBreakdown?, formatter: NumberFormat) {
    Box(Modifier.fillMaxWidth().background(Forest, RoundedCornerShape(26.dp)).padding(22.dp)) {
        Column {
            Text("Assalamu Alaikum", color = Gold, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text("Give with confidence.\nCalculate with care.", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, lineHeight = 31.sp)
            Spacer(Modifier.height(12.dp))
            Text("A private, organized way to estimate your Zakat.", color = Color.White.copy(alpha = .85f))
            Spacer(Modifier.height(18.dp))
            Button(onClick = onCalculate, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = ForestDark), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Calculate, null); Spacer(Modifier.width(8.dp)); Text("Start calculation", fontWeight = FontWeight.Bold)
            }
        }
    }
    Spacer(Modifier.height(18.dp))
    Text("Your overview", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        MetricCard("Latest estimate", result?.let { formatter.format(it.zakatDue) } ?: "—", Modifier.weight(1f))
        MetricCard("Nisab basis", "Silver / Gold", Modifier.weight(1f))
    }
    Spacer(Modifier.height(18.dp))
    Text("Explore", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
    Spacer(Modifier.height(10.dp))
    val shortcuts = listOf("Cash & Savings", "Gold", "Silver", "Business Assets", "Investments", "Debt Deductions", "Nisab & Prices", "History", "Islamic Learning", "Zakat Guide", "Hawl & Reminders", "Reports", "About Al-Noor", "Privacy", "Help & Disclaimer")
    shortcuts.chunked(2).forEach { pair ->
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            pair.forEach { name ->
                val page = pages.find { it.title == name }!!
                Card(modifier = Modifier.weight(1f).padding(bottom = 10.dp).clickable { onNavigate(name) }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(15.dp)) {
                        Icon(page.icon, null, tint = Forest, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.height(12.dp))
                        Text(name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("Open section", color = Muted, fontSize = 11.sp)
                    }
                }
            }
            if (pair.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun CalculatorScreen(
    cash: String, setCash: (String) -> Unit, gold: String, setGold: (String) -> Unit,
    silver: String, setSilver: (String) -> Unit, business: String, setBusiness: (String) -> Unit,
    investments: String, setInvestments: (String) -> Unit, other: String, setOther: (String) -> Unit,
    debts: String, setDebts: (String) -> Unit, basis: String, setBasis: (String) -> Unit,
    goldNisab: String, setGoldNisab: (String) -> Unit, silverNisab: String, setSilverNisab: (String) -> Unit,
    formatter: NumberFormat, status: String, onSave: () -> Unit, onCalculate: () -> Unit
) {
    Text("Zakat calculator", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = ForestDark)
    Text("Enter eligible values in Nigerian Naira (NGN). Leave a field at zero if not applicable.", color = Muted)
    Spacer(Modifier.height(14.dp))
    InfoCard("Important", "Use eligible amounts according to the scholarly method you follow. Do not double-count assets.")
    Spacer(Modifier.height(14.dp))
    Text("ASSETS", color = Forest, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.4.sp)
    MoneyField("Cash & savings", cash, setCash)
    MoneyField("Eligible gold value", gold, setGold)
    MoneyField("Eligible silver value", silver, setSilver)
    MoneyField("Business assets", business, setBusiness)
    MoneyField("Eligible investments", investments, setInvestments)
    MoneyField("Other eligible assets", other, setOther)
    Spacer(Modifier.height(10.dp))
    Text("DEDUCTIONS & NISAB", color = Forest, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.4.sp)
    MoneyField("Potentially deductible debts", debts, setDebts)
    Text("Nisab basis", fontWeight = FontWeight.SemiBold)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FilterChip(selected = basis == "Silver", onClick = { setBasis("Silver") }, label = { Text("Silver") })
        FilterChip(selected = basis == "Gold", onClick = { setBasis("Gold") }, label = { Text("Gold") })
    }
    MoneyField("Silver Nisab value (manual)", silverNisab, setSilverNisab)
    MoneyField("Gold Nisab value (manual)", goldNisab, setGoldNisab)
    Text("Price values are manual assumptions. They are not live market prices.", color = Muted, fontSize = 12.sp)
    if (status.isNotBlank()) Text(status, color = Color(0xFFB3261E), modifier = Modifier.padding(top = 8.dp))
    Spacer(Modifier.height(14.dp))
    Button(onClick = onCalculate, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
        Icon(Icons.Default.Calculate, null); Spacer(Modifier.width(8.dp)); Text("Calculate Zakat")
    }
    OutlinedButton(onClick = onSave, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
        Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save entries on this device")
    }
}

@Composable
private fun AssetDetailScreen(title: String, explanation: String, value: String, onValue: (String) -> Unit, onSave: () -> Unit) {
    Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = ForestDark)
    Spacer(Modifier.height(8.dp))
    Text(explanation, color = Muted, lineHeight = 22.sp)
    Spacer(Modifier.height(18.dp))
    MoneyField("Eligible value (NGN)", value, onValue)
    Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save entry") }
    Spacer(Modifier.height(12.dp))
    InfoCard("Remember", "Enter only the portion you have determined is eligible, and review your method with a qualified scholar if unsure.")
}

@Composable
private fun NisabScreen(basis: String, setBasis: (String) -> Unit, gold: String, setGold: (String) -> Unit, silver: String, setSilver: (String) -> Unit, onSave: () -> Unit) {
    Text("Nisab & prices", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = ForestDark)
    Spacer(Modifier.height(8.dp))
    Text("Choose the threshold you follow and enter values from a trusted local source.", color = Muted)
    Spacer(Modifier.height(16.dp))
    Text("Preferred Nisab", fontWeight = FontWeight.SemiBold)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FilterChip(selected = basis == "Silver", onClick = { setBasis("Silver") }, label = { Text("Silver") })
        FilterChip(selected = basis == "Gold", onClick = { setBasis("Gold") }, label = { Text("Gold") })
    }
    MoneyField("Silver Nisab value (NGN)", silver, setSilver)
    MoneyField("Gold Nisab value (NGN)", gold, setGold)
    InfoCard("Price status: manual", "Automatic price updates are not connected in this release. Verify the current price and update these fields yourself.")
    Spacer(Modifier.height(12.dp))
    Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Text("Save Nisab settings") }
}

@Composable
private fun ResultsScreen(result: ZakatBreakdown?, formatter: NumberFormat, onSave: () -> Unit, onHistory: () -> Unit, status: String) {
    Text("Your results", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = ForestDark)
    Spacer(Modifier.height(12.dp))
    if (result == null) {
        InfoCard("No calculation yet", "Open Zakat Calculator and enter your eligible assets to see the breakdown.")
    } else {
        Box(Modifier.fillMaxWidth().background(Forest, RoundedCornerShape(24.dp)).padding(22.dp)) {
            Column {
                Text(if (result.eligible) "Estimated Zakat due" else "Below selected Nisab", color = Gold, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Text(formatter.format(result.zakatDue), color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.Bold)
                Text(if (result.eligible) "Illustrative estimate at 2.5%" else "No Zakat calculated because net assets are below the entered Nisab.", color = Color.White.copy(alpha = .85f))
            }
        }
        Spacer(Modifier.height(16.dp))
        ResultLine("Total entered eligible assets", formatter.format(result.totalAssets))
        ResultLine("Potential deductions applied", formatter.format(result.deductions))
        ResultLine("Net eligible assets", formatter.format(result.netAssets))
        ResultLine("Selected Nisab", formatter.format(result.nisab))
        ResultLine("Rate used", "2.5%")
        Spacer(Modifier.height(16.dp))
        InfoCard("Please review", "This result uses your manual inputs and simplified rules. It is not a fatwa and may not reflect every scholarly position.")
        Spacer(Modifier.height(12.dp))
        Button(onClick = onSave, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.BookmarkAdd, null); Spacer(Modifier.width(8.dp)); Text("Save result to history") }
        OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth()) { Text("View history") }
    }
    if (status.isNotBlank()) Text(status, color = Forest, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun HistoryScreen(history: List<JSONObject>, formatter: NumberFormat, onClear: () -> Unit) {
    Text("Calculation history", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = ForestDark)
    Spacer(Modifier.height(8.dp))
    Text("Stored on this device only.", color = Muted)
    Spacer(Modifier.height(14.dp))
    if (history.isEmpty()) InfoCard("No saved results", "When you save a calculation result, it will appear here.")
    history.forEachIndexed { index, item ->
        Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text(item.optString("date", "Saved calculation"), color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                Text(formatter.format(item.optDouble("zakat", 0.0)), fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Forest)
                Text("Net assets: ${formatter.format(item.optDouble("net", 0.0))}", color = Muted)
            }
        }
    }
    if (history.isNotEmpty()) OutlinedButton(onClick = onClear, modifier = Modifier.fillMaxWidth()) { Text("Clear local history") }
}

@Composable
private fun ReportScreen(result: ZakatBreakdown?, formatter: NumberFormat, onShare: () -> Unit, status: String) {
    Text("Reports", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = ForestDark)
    Spacer(Modifier.height(8.dp))
    Text("A quick summary of your latest calculation.", color = Muted)
    Spacer(Modifier.height(16.dp))
    if (result == null) InfoCard("No report yet", "Calculate your Zakat first.")
    else {
        InfoCard("Estimated Zakat", formatter.format(result.zakatDue))
        ResultLine("Net assets", formatter.format(result.netAssets))
        ResultLine("Nisab", formatter.format(result.nisab))
        Text("PDF export is not included in this initial build. Review or copy the result manually.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onShare, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text("Share options") }
    }
    if (status.isNotBlank()) Text(status, color = Muted)
}

@Composable
private fun SettingsScreen(language: String, setLanguage: (String) -> Unit, basis: String, setBasis: (String) -> Unit, onNavigate: (String) -> Unit) {
    Text("Settings", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = ForestDark)
    Spacer(Modifier.height(16.dp))
    Text("Language", fontWeight = FontWeight.SemiBold)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FilterChip(selected = language == "English", onClick = { setLanguage("English") }, label = { Text("English") })
        FilterChip(selected = language == "Arabic", onClick = { setLanguage("Arabic") }, label = { Text("العربية") })
    }
    Text("Note: Arabic is a language preference placeholder; complete professional Arabic translation and RTL review are still required.", color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(16.dp))
    Text("Default Nisab", fontWeight = FontWeight.SemiBold)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FilterChip(selected = basis == "Silver", onClick = { setBasis("Silver") }, label = { Text("Silver") })
        FilterChip(selected = basis == "Gold", onClick = { setBasis("Gold") }, label = { Text("Gold") })
    }
    Spacer(Modifier.height(16.dp))
    InfoCard("Currency", "Nigerian Naira (NGN). Currency is displayed in local Nigerian formatting.")
    listOf("Privacy", "About Al-Noor", "Help & Disclaimer").forEach { name ->
        OutlinedButton(onClick = { onNavigate(name) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text(name) }
    }
}

@Composable
private fun InfoScreen(title: String, description: String, bullets: List<String>) {
    Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = ForestDark)
    Spacer(Modifier.height(8.dp))
    Text(description, color = Muted, lineHeight = 22.sp)
    Spacer(Modifier.height(16.dp))
    bullets.forEach { item ->
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.CheckCircle, null, tint = Gold, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text(item, color = Ink, lineHeight = 21.sp)
        }
    }
}

@Composable
private fun MoneyField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        leadingIcon = { Text("₦", color = Forest, fontWeight = FontWeight.Bold) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = ForestDark)
            Spacer(Modifier.height(5.dp))
            Text(body, color = Muted, lineHeight = 21.sp, fontSize = 13.sp)
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(label, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text(value, color = ForestDark, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}

@Composable
private fun ResultLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Text(value, color = Ink, fontWeight = FontWeight.SemiBold)
    }
    HorizontalDivider(color = Color(0xFFE7EAE6))
}

private fun loadHistory(prefs: android.content.SharedPreferences): List<JSONObject> {
    val raw = prefs.getString("history", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { arr.getJSONObject(it) }
    } catch (_: Exception) { emptyList() }
}

private fun saveHistory(prefs: android.content.SharedPreferences, result: ZakatBreakdown): List<JSONObject> {
    val arr = JSONArray()
    val old = loadHistory(prefs)
    JSONObject().apply {
        put("date", java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(java.util.Date()))
        put("zakat", result.zakatDue)
        put("net", result.netAssets)
        put("nisab", result.nisab)
    }.also { arr.put(it) }
    old.take(49).forEach { arr.put(it) }
    prefs.edit().putString("history", arr.toString()).apply()
    return loadHistory(prefs)
}
