# Al-Noor Zakat Calculator Professional

Native Android app built with Kotlin and Jetpack Compose. This repository is structured for GitHub Actions to build a debug APK; it is not a web wrapper.

## Included in this project
- A branded Material 3 dashboard and 20 navigable app sections
- Zakat calculator for cash, gold, silver, business assets, investments, other eligible assets, and deductible debts
- Nisab selection (silver or gold), with editable demonstration price assumptions
- Results breakdown and local device-only calculation history
- English/Arabic language toggle foundation and RTL support in the Android manifest
- Settings, privacy/disclaimer, educational guidance, reminders screen, report/share action
- GitHub Actions workflow to build APK and run unit tests

## Important limitations before public release
- Gold/silver prices are **manual editable assumptions**, not a verified live market feed. The app labels them as such. A production price provider/API, source attribution, timestamping, caching, and stale-data warnings must be configured before claiming live prices.
- Zakat treatment can vary by scholarly opinion, asset type, debts, and personal circumstances. Educational screens are general information, not a fatwa. Have qualified scholars review the rules and wording before release.
- History is stored locally in Android SharedPreferences on this initial release; no account or cloud sync is included.
- PDF export, scheduled notifications, and production-grade Arabic translations are marked as future enhancements rather than represented as fully implemented.
- This source archive has not been built or tested on a real Android device in this environment. GitHub Actions is provided to perform a build/test after upload.

## Build APK on GitHub from an Android phone
1. Extract this ZIP using your phone's file manager or an archive app.
2. Create a repository at https://github.com/new (for example `al-noor-zakat-calculator`).
3. In the repository, choose **Add file → Upload files**. Upload the *contents* of this folder, including `.github/workflows/android-apk.yml`, then commit.
4. Open the repository's **Actions** tab and select **Build Al-Noor Android APK**. Run workflow if it did not start automatically.
5. When the workflow finishes green, open the run, scroll to **Artifacts**, and download `Al-Noor-Zakat-Calculator-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser/file manager.

## Build locally
Use JDK 17, Android SDK platform 35, and Gradle 8.10.2:
`gradle assembleDebug testDebugUnitTest`

## Package identity
`org.alnoor.zakat` — change carefully before a public Play Store release.
